# GLM P0 Architecture Review Package — v1

## Purpose
This package is for **Stage 1 read-only review** of the Comprehensive Program and Budget System architecture. Upload this ZIP to GLM and submit `01_PROMPT_STAGE1.md` as the instruction.

## Important
- This package is an evidence/review bundle, not an executable deployment package.
- No SQL should be executed.
- `CapitalBudgetManagement_Lab_Stage3_DRAFT_NOT_EXECUTED.sql` is included for review only. **DO NOT EXECUTE.**
- The current state of the customer's SQL Server database has not been independently verified by this package.
- The six P0 decisions are owner decisions documented for analysis; they do not imply implementation.
- Do not ask GLM to modify files, repositories, or databases in this stage.

## Package layout
- `01_PROMPT_STAGE1.md`: paste this prompt into GLM.
- `03_P0_Architecture_Decision_Package/`: previously prepared P0 decision package.
- `04_LabSQL_Review_and_DB_Reconciliation/`: previous static review/reconciliation reports.
- `05_Continuation_and_Next_Step/`: continuation report, status matrix, and inventory.
- `06_Source_Artifacts/`: HTML, SQL scripts, data dictionary, and read-only review notes available in this working environment.

## Source completeness
This package includes only the source artifacts available in the current working environment. It does not claim that the original v6 and Appendix v2 source sets are complete. GLM must explicitly identify any missing source files needed for a valid comparison.

## Suggested workflow
1. Upload this ZIP to GLM.
2. Paste `01_PROMPT_STAGE1.md` into the prompt/instructions field.
3. Ask GLM to inspect the ZIP contents and return the nine Markdown deliverables in a separate output folder.
4. Do not approve any SQL execution or code modification.
5. Bring GLM's report back here for evidence and consistency review before moving to Stage 2.
