# GLM Prompt — Stage 1: Read-only architecture evidence review

## Role
Act as a senior software architect specializing in SQL Server 2022, enterprise data modeling, ASP.NET Core Web API, IIS, application security, and controlled database migration.

## Project
The Comprehensive Program and Budget System has five modules:
1. Budget Management and Budget Requests
2. Demand and Financing
3. Procurement
4. Contractor Procurement
5. Project Control

The long-term target is a secure multi-user application using ASP.NET Core Web API, SQL Server, and IIS. It must support capital budget now and permit current budget to be added later. Common workflows should share a core model where appropriate, while budget-specific headings, rules, forms, and reports remain separable.

## Authoritative owner decisions (P0)
- **P0-1 / D-06 — PersonnelNo:** Uniqueness must be enforced before operational data entry begins. A personnel number must never be reassigned to another person after the original person leaves. The field length must be determined from the organization's actual personnel-number format and evidence; do not guess a final length.
- **P0-2 — Audit:** `AuditEvent` is the target logical source for business and security audit events. Final schema and treatment of the existing `app.AuditLog` depend on reviewing existing data, references, and consumers. Do not drop or alter the table.
- **P0-3 — Authentication:** Support both Local and Active Directory authentication, with an authorized site/organization administrator selecting the active method according to that organization's policy. This does not imply both methods must be active simultaneously. Authentication, session handling, and authorization must be server-side.
- **P0-4 — Audit retention/purge:** Purge design should be controlled, batched, observable, safely stoppable/resumable, and least-privilege. Batch size 5,000 is only a provisional starting point, not proven optimal. Do not execute purge or delete data.
- **P0-5 — Architecture convergence:** v6 is the requirements/design reference baseline. Reuse useful components from Lab and Appendix v2 only after compatibility review. Produce one coherent target architecture; do not blindly merge designs.
- **P0-6 — Database naming:** Target database `CapitalBudgetDB`; target lab database `CapitalBudgetDB_Lab`; existing `CapitalBudgetManagement_Lab` must remain untouched. Target schemas: `dbo` for core, `rep` for reporting, `audit` for audit. Validate feasibility against the real environment before treating these as executable configuration.

## Known caveats
- Prior reports mention Lab SQL scripts Stage1, Stage2, and a Stage3 draft, but the actual state of the customer's SQL Server and data has not been independently verified.
- `CapitalBudgetManagement_Lab_Stage3_DRAFT_NOT_EXECUTED.sql` is a draft and must not be executed.
- Prior review noted a possible `BIGINT` versus `INT` key-type mismatch; verify it directly in the supplied artifacts.
- Historical documents had conflicting assumptions about personnel-number reuse. The owner's current decision above supersedes those earlier assumptions.
- A prior report identified differences between the existing `app.AuditLog` and the proposed `AuditEvent` design. Verify exact claims from the supplied files.
- Do not assume v6 or Appendix v2 source artifacts are present unless you can actually locate them in the package. If a referenced artifact is missing, list it as missing and request it rather than inventing its contents.

## Mission — analysis and documentation only
1. Inventory all files supplied in the package and classify them (decision record, architecture document, SQL script, HTML source, data dictionary, report, or other).
2. Review the actual contents of the files available to you. Cite exact file paths and line numbers/sections for key claims wherever possible.
3. Separate:
   - facts directly verified in supplied files,
   - statements reported by earlier documents,
   - assumptions,
   - unknowns that require access to the real SQL Server or the organization.
4. Compare the v6, Lab, and Appendix v2 paths only to the extent that their actual source artifacts are available. Explicitly mark missing source documents.
5. Build a conflict matrix covering at least:
   - `PersonnelNo` uniqueness, non-reuse, and length;
   - primary/foreign key types (`INT` vs `BIGINT`);
   - users, roles, authentication, and session handling;
   - `AuditLog` versus `AuditEvent`;
   - database names and schemas;
   - table relationships and migration dependencies;
   - capital budget and future current-budget support.
6. For each conflict, record: ID, exact evidence, affected files/objects, risk, recommended resolution, validation needed, and whether the owner's decision already resolves the business direction.
7. Produce an evidence register and a traceability matrix linking each P0 decision to the files reviewed, outstanding verification, and acceptance criteria.
8. Produce a prioritized next-step plan. The next step should be evidence review and architecture reconciliation, not SQL execution.
9. Do not claim a test passed unless you actually ran it and can provide the command, environment, and output. Static inspection is not execution verification.

## Non-negotiable safety constraints
- Do NOT execute SQL or connect to any database.
- Do NOT create, drop, or modify databases, schemas, tables, indexes, or data.
- Do NOT edit or overwrite the supplied HTML, source code, or SQL scripts.
- Do NOT perform a migration or data cleanup.
- Do NOT change any GitHub repository.
- Do NOT generate a production-ready migration script in this stage.
- Do NOT claim that the customer's Lab database has a specific state unless the supplied evidence actually establishes it.
- If a file is absent, say so. Do not infer its contents from its name or a prior summary.
- Preserve the owner's six P0 decisions unless direct evidence reveals a technical contradiction; if so, explain the contradiction and ask for a decision instead of silently changing it.

## Required deliverables
Create these Markdown files in a separate output folder, without altering inputs:
1. `EXECUTIVE_SUMMARY.md`
2. `FILE_INVENTORY.md`
3. `EVIDENCE_REGISTER.md`
4. `ARCHITECTURE_CONFLICT_MATRIX.md`
5. `DATABASE_SCHEMA_COMPARISON.md`
6. `P0_DECISION_TRACEABILITY.md`
7. `OPEN_QUESTIONS_AND_RISKS.md`
8. `RECOMMENDED_TARGET_ARCHITECTURE.md`
9. `NEXT_STEP_PLAN.md`

End with a concise status summary:
- what you actually inspected;
- what is evidenced versus merely reported;
- what source artifacts are missing;
- the top unresolved conflicts;
- the recommended next step.

This stage authorizes read-only analysis and documentation only. It does not authorize code changes, SQL execution, database changes, or migration.
