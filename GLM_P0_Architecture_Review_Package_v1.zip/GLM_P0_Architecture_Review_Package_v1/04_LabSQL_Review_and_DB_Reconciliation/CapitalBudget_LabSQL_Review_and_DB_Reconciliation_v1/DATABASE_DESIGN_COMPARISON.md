# مقایسه دو مسیر طراحی دیتابیس و پیشنهاد معماری هدف

| مورد | مقدار |
|---|---|
| مسیر A | طراحی معماری v6 — «۴۰ جدول» (سند ۰۳ Stage1_Design v6) |
| مسیر B | طراحی آزمایشگاهی — «۱۸ جدول» (سه اسکریپت GitHub) |
| وضعیت شمارش‌ها | ۴۰ = A:4+B:15+C:6+D:3+E:4+F:4+G:4 — **شخصاً راستی‌آزمایی شد**؛ ۱۸ = ۹+۷+۲ — **با کنترل‌های C-09/C-16/C-23 تأیید شد** |
| مسیر C (کشف تکمیلی این نشست) | خط پیاده‌شده پیوست v2 (تنها باند با شاهد اجرا — ۱۰۸/۱۰۸ TRX): زیرمجموعه ۸ جدولی `dbo` + FILESTREAM |
| قاعده بی‌طرفی | «کم‌جدول‌تر = ساده‌تر/بهتر» فرض نشد؛ «۴۰ جدولی = برتر» نیز بدون شواهد فرض نشد |

---

## ۱. ماتریس تطبیق جدول‌به‌جدول (۱۸ جدول Lab در برابر v6)

برچسب‌ها طبق §5 مأموریت: **مستقیم** = معادل مستقیم | **تفاوت** = معادل با تفاوت ساختاری | **ادغام** = چند موجودیت v6 در یک جدول Lab | **جدید** = موجودیت بدون معادل v6 | **ناموجود** = در v6 هست، در Lab نیست | **تصمیم** = نیازمند تصمیم معماری | **شواهد ناکافی**

| # | جدول Lab (فایل:خط) | نزدیک‌ترین موجودیت v6 | برچسب | تفاوت‌های کلیدی (شاهد) |
|---|---|---|---|---|
| ۱ | app.SchemaVersion (S1:26-37) | ندارد (EF Migrations، سند ۰۶ §Migration) | جدید / تفاوت-فلسفه | دفتر نسخه DB-محور در برابر Migration شماره‌دار + اسکریپت Idempotent — سازگار قابل هم‌زیستی؛ تصمیم نسخه‌بندی واحد (تصمیم) |
| ۲ | app.Users (S1:43-66) | dbo.Users (A1) | تفاوت — 🔴 تصمیم | بدون ستون‌های احراز (C-13)؛ PersonnelNo 50 بدون UX در برابر 20 با UX فیلترشده D-06 (C-10)؛ Username 100/بدون CI در برابر 50/CI؛ PositionTitle/AvatarUrl/ExtraJson در برابر Position/Avatar VARBINARY/ChainCommitterId+ChainSeniorId/MustChangePassword |
| ۳ | app.Managements (S1:70-83) | B1 Managements | تفاوت | SourceId+ExtraJson+UpdatedAt اضافی در Lab؛ v6 حداقلی‌تر؛ سازگاری مفهومی کامل |
| ۴ | app.Units (S1:86-101) | B2 Units | تفاوت | در v6 `ManagementId FK NOT NULL`؛ در Lab NULL-پذیر (S1:92) — سلسله‌مراتب اجباری v6 تضمین نمی‌شود |
| ۵ | app.Programs (S1:115-147) | C2 Requests | تفاوت — 🔴 تصمیم | راهبرد PayloadJson در برابر ۳۰+ ستون صریح؛ بدون Code پروتکل‌محور/Status FK/BudgetHeadId/CeoRequired/امضاهای JSON (S1:117-146)؛ مبلغ 19,4 در برابر 18,2؛ در v6 تاریخ D-04 با ستون‌های *J |
| ۶ | app.MicroRequests (S1:151-171) | C3 RequestMicros | تفاوت — تصمیم | بدون SeqNo UNIQUE/AHP/ExecPath/ApprovalNo/ProjectControl/MonthlyPlans (S1:153-170)؛ UQ(ProgramId,SourceMicroId) در برابر UQ(RequestId,SeqNo) |
| ۷ | app.CatalogItems (S1:177-193) | B4..B12، B14، B15 (۱۰ جدول) + بخشی B13 | ادغام — 🔴 تصمیم | کاتالوگ عمومی CatalogType در برابر ۱۰ جدول اختصاصی با FK؛ یکپارچگی ارجاعی به‌جای FK در JSON/کد؛ UQ(Type,Source) خوب؛ تصمیم معماری: انعطاف JSON در برابر یکپارچگی FK |
| ۸ | app.AppSettings (S1:197-207) | G1 SystemSettings | تفاوت | کلید ۱۰۰ در برابر ۵۰؛ **بدون RowVersion** (نقض D-14 برای تنظیمات — v6 صریحاً RowVersion SystemSettings را برای جلوگیری از بازنویسی دو مدیری الزام کرد) |
| ۹ | app.AuditLog (S1:212-227) | G3 SecurityEvents + مدل v5.3 audit.AuditEvent | تداخل — 🔴 تصمیم (P0-2) | ۸ ستون عمومی در برابر ۲۰ ستونه چهار-دسته‌ای؛ بدون Category/Result/ایندکس زمانی؛ سند اختصاصی: LOGGING_AND_AUDIT_RECONCILIATION.md |
| ۱۰ | app.Roles (S2:19-32) | A2 Roles | تفاوت | کلید جانشین RoleId+UQ(RoleCode) در برابر کلید طبیعی Code PK؛ TitleFa/SortOrder در برابر RoleName/Description/IsSystem |
| ۱۱ | app.UserRoles (S2:49-64) | A3 UserRoles | تفاوت | (UserId,RoleId) با IDENTITY+UQ در برابر PK مرکب (UserId,RoleCode) — مسیر C دقیقاً الگوی مرکب v6 را پیاده کرده (Entities.cs:21-27)؛ Lab دارای IsActive/AssignedBy اضافی |
| ۱۲ | app.BudgetYears (S2:66-81) | B3 BudgetYears | تفاوت | کلید جانشین+UQ(YearValue)+CHECK 1300..1600 در برابر Year INT natural+Active؛ IsClosed/Notes اضافی Lab |
| ۱۳ | app.BudgetHeads (S2:83-104) | B13 BudgetHeads | تفاوت | Kind nvarchar(20) NULL+CHECK در برابر nvarchar(10) NOT NULL CHECK؛ SourceId+UX فیلترشده در Lab (نقطه قوت مهاجرت — C-19) |
| ۱۴ | app.BudgetEnvelopes (S2:106-127) | F1 BudgetEnvelopes | تفاوت — 🔴 تصمیم | Lab: سال+نوع+مبلغ بدون سرفصل و بدون محدوده دید؛ v6: Year+HeadId NOT NULL+Kind NOT NULL+ScopeManagementId+RowVersion (SR2-05/C-22) |
| ۱۵ | app.BudgetCeilings (S2:129-149) | F2 BudgetCeils | تفاوت | بدون UNIQUE(Year,Head) (SR2-04/C-20)؛ کلید سال جانشین در برابر Year INT؛ RowVersion هر دو |
| ۱۶ | app.ManualBudgetAllocations (S2:151-174) | F3 BudgetAllocations | تفاوت | YearId جانشین در برابر Year/Head/Unit؛ بدون UX SourceId (SR2-03)؛ بدون Note? دارد Note؛ معادل مفهومی کامل تخصیص به واحد |
| ۱۷ | app.MicroRequestRouting (S3:66-92) | معادل جدولی ندارد — نزدیک‌ترین: C3.ExecPath ('buy'/'contract') | جدید — 🔴 تصمیم | مدل «جدول مسیریابی» در برابر «ستون روی ردیف»؛ RouteCode (purchase_request/contractor_supply) ≈ (buy/contract)؛ قاعده یک‌مسیر با UNIQUE(MicroRequestId) تحکیم شده (C-24) — نقاط قوت باید در معماری هدف حفظ شود |
| ۱۸ | app.WorkflowEvents (S3:96-124) | E1 RequestHistory | تداخل — تصمیم | RequestHistory فقط RequestId+امضا/ByDelegate؛ WorkflowEvents پلی‌مورف program/micro بدون FK/ضدتکرار (SR3-03/C-26)؛ همپوشانی سه‌گانه با UAL v5.3 |

### ۱-۱) موجودیت‌های v6 بدون هر معادل در خط Lab (۲۲ مورد — «پیاده‌نشده»)

A4 UserSignatures | B4 RequestTypes، B5 PriorityOptions، B6 ActivityDomains، B7 UnitsOfMeasure، B8 BuildPeriods، B9 FinancialBenefits، B10 NonFinancialBenefits، B11 GeneralGoals، B12 SpecialRequirements، B14 ProgramTypes، B15 ProgramTitles (بجز پوشش جزئی از CatalogItems) | C1 RequestStatuses | C4 MicroMonthlyPlans | C5 RequestAttachments (در مسیر C پیاده و آزمون شده) | C6 NumberingCounters | D1..D3 AHP | E2 Notifications | E3 Referrals | E4 Delegations | F4 BudgetOverLogs | G2 GuideItems | G4 LoginLockouts (در مسیر C هست) + جداول احراز v2: AuthSessions (در مسیر C هست)، SystemAuthSettings، UserExternalIdentities.

> نتیجه کمّی: از ۴۰ جدول v6، خط Lab حداکثر ۱۶ موجودیت را (اغلب با تفاوت ساختاری) پوشش می‌دهد و ۲۴ موجودیت (شامل کل AHP، اعلان‌ها، ارجاع، تفویض، شماره‌گذاری پروتکلی، سقف‌گذاری OverLog و وضعیت‌های کنترل‌شده) بدون معادل است. این «کم‌جدول‌تر» یعنی «پوشش‌نشدن نیازمندی‌های ممیزی‌شده HTML» نه سادگی بیشتر — تا تصمیم مالک، هیچ برتری‌ای به هیچ‌کدام نسبت داده نمی‌شود.

## ۲. وابستگی‌ها (تفاوت گراف وابستگی)

- **Lab:** زنجیره ساده Users→Managements/Units→Programs→MicroRequests + ریفلنس بودجه BudgetYears→Heads→Envelopes/Ceilings/Allocations؛ **حلقه بودجه-درخواست قطع است**: Programs هیچ پیوندی به BudgetHeads/Allocations ندارد (فقط BudgetKind آزاد در Stage3) — کنترل «مصوب سرفصل» (`budApprovedSum` کد مرجع خط ۷۶۳۰) در خط Lab بی‌پایگاه است.
- **v6:** گراف کامل با ۹ وضعیت FK-دار (C1)، پیوند Requests.BudgetHeadId/RequestMicros.BudgetHeadId، AHP سه‌جدوله، NumberingCounters برای کد پروتکل‌محور، و مرزبندی append-only (E1/F4).
- **پیامد:** اگر خط Lab مبنا شود، لایه کنترل بودجه باید یا در Backend بازسازی شود یا جداول پیوندی اضافه شوند — هر دو «تغییر اسکریپت‌های موجود» را لازم می‌کند که بدون اجازه کارفرما ممنوع است.

## ۳. ریسک‌های مهاجرت بین دو مسیر

| ریسک | شرح | شدت |
|---|---|---|
| R-1 دوبله‌شدن مهاجرت | نبود UX SourceId روی Envelopes/Ceilings/Allocations (SR2-03) | 🟠 |
| R-2 گم‌شدن ساختار در JSON | انتقال از PayloadJson به ستون‌های صریح v6 نیازمند نگاشت فیلدبه‌فیلد ۹۹ نیازمندی + اعتبارسنجی؛ JSON «حفظ ساختار» است نه قاعده | 🔴 |
| R-3 ناسازگاری نوع/دقت | int↔BIGINT، 19,4↔18,2، nvarchar(50)↔(20) پرسنلی، طول‌های نام | 🟠 |
| R-4 نقض D-06 قبل از مهاجرت | بدون UX پرسنلی، داده تکراری وارد Lab می‌شود و بعداً پاک‌سازی سخت می‌شود (ترتیب: اول ایندکس، بعد مهاجرت) | 🔴 |
| R-5 دو جدول Users در یک DB | اجرای هر دو خانواده اسکریپت روی `CapitalBudgetManagement_Lab` | 🔴 |
| R-6 وضعیت‌های آزاد | StatusCode متن‌آزاد Lab در برابر ۹ وضعیت کنترل‌شده v6 — نگاشت وضعیت‌ها پیش‌نیاز مهاجرت است | 🟠 |

## ۴. پیشنهاد معماری هدف (پیش‌نویس — هیچ‌کدام قطعی نیست؛ تصمیم با مالک/DBA)

**گزینه ۱ — v6 مبنا، Lab صرفاً sandbox:** خط Lab برای آزمایش ساختار و آشنایی DBA می‌ماند؛ دیتابیس هدف از DB-01..DB-13 سند ۰۶ v6 ساخته می‌شود. هزینه: اسکریپت‌های Lab از مسیر اصلی خارج می‌شوند. سود: پوشش کامل نیازمندی‌های ممیزی‌شده + تصمیم‌های قطعی D-0x در طراحی.
**گزینه ۲ — Lab مبنا، v6 به‌عنوان مرجع نیازمندی:** خط Lab گسترش می‌یابد (Stage4+) تا ۲۴ موجودیت جاافتاده و قیود (SR1-02..SR2-05) را بپوشاند. هزینه: بازنویسی گسترده و تکرار مسیری که v6 قبلاً با دقت طی کرده؛ ریسک خطای طراحی مجدد.
**گزینه ۳ — همگرایی برنامه‌ریزی‌شده (پیشنهاد معمار برای بحث):** مبنای ساخت «دیتابیس هدف» اسناد v6 می‌ماند (شامل تصمیم‌های قطعی و پوشش ۴۰ جدولی)؛ از خط Lab سه دارایی مشخص منتقل می‌شود: (الف) الگوی `SchemaVersion` به‌عنوان لایه شفافیت DBA، (ب) جدول `MicroRequestRouting` به‌عنوان تحکیم DBی قاعده یک‌مسیر (در کنار ExecPath یا به‌جای آن — تصمیم)، (ج) الگوی SourceId/UX فیلترشده BudgetHeads برای همه جدول‌های مهاجرتی. مسیر C (پیوست پیاده‌شده) به‌عنوان زیرمجموعه سازگار v6 حفظ و تناقض int/BIGINT در همان تصمیم حل می‌شود.
- **پیش‌فرض محافظه‌کار تا تصمیم مالک:** هیچ‌کدام اجرا نمی‌شود؛ هیچ Backendای به خط Lab وصل نمی‌شود؛ مسیر C دست‌نخورده می‌ماند.
- **آنچه مستقل از گزینه ثابت است:** قیدهای قطعی D-01/D-02/D-04/D-06/D-14/D-16/D-19 باید در هر معماری هدف برقرار باشد؛ قاعده یک‌مسیر micro باید در DB + Backend دوگانه اعمال شود؛ تفکیک بودجه سرمایه‌ای/جاری با CHECK + نقش‌های جدا (budget/budget_cur) در هر دو خط موجود و حفظ‌شدنی است.

> یادآوری §5 مأموریت: شمارش‌های ۴۰ و ۱۸ اکنون هر دو «راستی‌آزمایی‌شده» هستند و برچسب‌های بالا صرفاً بر متن واقعی فایل‌ها (نه نام یا گزارش) بنا شده‌اند.
