#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CONT-2 — بازبینی استاتیک قابل تکرار سه اسکریپت Lab (الگوی کنترل‌های X/W)
هیچ SQLی اجرا نمی‌شود؛ فقط تحلیل متن. خروجی: گزارش کنترل‌ها (PASS/FAIL) به stdout.
"""
import re, io, sys, hashlib, os

SRC = "/home/z/my-project/continuation_workspace/extracted"
FILES = {
    "Stage1": "CapitalBudgetManagement_Lab_Stage1.sql",
    "Stage2": "CapitalBudgetManagement_Lab_Stage2.sql",
    "Stage3": "CapitalBudgetManagement_Lab_Stage3_DRAFT_NOT_EXECUTED.sql",
}

def load(name):
    with io.open(os.path.join(SRC, FILES[name]), encoding="utf-8-sig") as f:
        lines = f.read().splitlines()
    return lines

results = []
def ctrl(cid, desc, ok, evidence=""):
    results.append((cid, desc, "PASS" if ok else "FAIL", evidence))

def strip_comments(code_lines):
    out, in_block = [], False
    for ln in code_lines:
        s, res, i = ln, "", 0
        while i < len(s):
            if in_block:
                j = s.find("*/", i)
                if j == -1: i = len(s)
                else: in_block, i = False, j + 2
            else:
                a = s.find("/*", i); b = s.find("--", i)
                if a == -1 and b == -1: res += s[i:]; break
                if b != -1 and (a == -1 or b < a): res += s[i:b]; break
                j = s.find("*/", a + 2)
                if j == -1: res += s[i:a]; in_block = True; break
                res += s[i:a]; i = j + 2
        out.append(res)
    return out

texts, codes = {}, {}
for k in FILES:
    texts[k] = load(k)
    codes[k] = strip_comments(texts[k])

# ---------- کنترل‌های عمومی ----------
for k in FILES:
    raw = "\n".join(codes[k])
    L = lambda pat: [i + 1 for i, ln in enumerate(codes[k]) if re.search(pat, ln, re.I)]
    # C-01: ممنوعیت DROP/TRUNCATE/DELETE (بدون کامنت)
    bad = L(r'\bDROP\s+TABLE\b|\bTRUNCATE\s+TABLE\b|\bDELETE\s+FROM\b') + L(r'\bDROP\s+INDEX\b|\bDROP\s+CONSTRAINT\b')
    ctrl(f"C-01[{k}]", "بدون DROP/TRUNCATE/DELETE (بدون کامنت)", not bad, f"خطوط: {bad}" if bad else "صفر مورد")
    # C-02: گارد کانتکست دیتابیس
    guard = bool(re.search(r"DB_NAME\(\)\s*<>\s*N'CapitalBudgetManagement_Lab'", raw))
    ctrl(f"C-02[{k}]", "گارد DB_NAME <> CapitalBudgetManagement_Lab با THROW", guard, "THROW 51000" if guard else "غایب")
    # C-03: USE صحیح
    use_ok = bool(re.search(r"USE\s*\[CapitalBudgetManagement_Lab\]", raw))
    ctrl(f"C-03[{k}]", "USE [CapitalBudgetManagement_Lab] هدف آزمایشگاهی", use_ok)
    # C-04: CREATE DATABASE غایب (طبق قاعده: ساخت DB توسط DBA)
    cd = L(r'\bCREATE\s+DATABASE\b')
    ctrl(f"C-04[{k}]", "بدون CREATE DATABASE", not cd, f"خطوط: {cd}" if cd else "صفر مورد")
    # C-05: الگوی THROW — پیام لفظی (نه عبارتی)
    th = L(r'\bTHROW\b')
    expr_bad = [n for n in th if n - 1 < len(codes[k]) and re.search(r"THROW\s*@", codes[k][n - 1])]
    ctrl(f"C-05[{k}]", "THROW فقط با پیام لفظی/بدون @ (درس LOG-FIX-12)", not expr_bad, f"{len(th)} سایت THROW؛ عبارتی: {expr_bad}")
    # C-06: توازن TRY/CATCH
    try_n = len(L(r'\bBEGIN\s+TRY\b')); catch_n = len(L(r'\bBEGIN\s+CATCH\b'))
    ctrl(f"C-06[{k}]", "توازن BEGIN TRY / BEGIN CATCH", try_n == catch_n, f"TRY={try_n} CATCH={catch_n}")
    # C-07: ROLLBACK مشروط XACT_STATE در CATCH
    if catch_n:
        ok7 = bool(re.search(r"XACT_STATE\(\)\s*<>\s*0\s*ROLLBACK", raw))
        ctrl(f"C-07[{k}]", "ROLLBACK مشروط XACT_STATE() در مسیر CATCH", ok7)
    # C-08: XACT_ABORT ON
    ctrl(f"C-08[{k}]", "SET XACT_ABORT ON", bool(re.search(r"SET\s+XACT_ABORT\s+ON", raw, re.I)))

# ---------- کنترل‌های اختصاصی Stage1 ----------
s1 = "\n".join(codes["Stage1"])
L1 = lambda pat: [i + 1 for i, ln in enumerate(codes["Stage1"]) if re.search(pat, ln, re.I)]
tables_s1 = re.findall(r"CREATE TABLE\s+(?:app\.)?(\w+)", s1)
ctrl("C-09", "Stage1 = ۹ جدول دقیق", len(tables_s1) == 9, f"{len(tables_s1)}: {sorted(tables_s1)}")
p_idx = L1(r"PersonnelNo\s+nvarchar\(50\)\s+NULL")
uq_p = L1(r"UX_Users_PersonnelNo|UNIQUE\s*\(PersonnelNo\)")
ctrl("C-10", "یافته P-02/D-06: PersonnelNo بدون ایندکس یکتا (ستون در خط ۵۲)", bool(p_idx) and not uq_p, f"ستون: {p_idx}؛ ایندکس یکتا: {uq_p or 'هیچ'}")
uq_u = L1(r"UQ_Users_Username")
ctrl("C-11", "یافته P-03: UQ_Users_Username موجود", bool(uq_u), f"خط {uq_u}")
al = L1(r"CREATE TABLE\s+app\.AuditLog")
ctrl("C-12", "یافته P-04: app.AuditLog عمومی موجود (۸ ستون)", bool(al), f"خط {al}")
no_pwd = not re.search(r"PasswordHash|PasswordSalt|MustChangePassword|LastLoginAtUtc", s1)
ctrl("C-13", "یافته P-01: هیچ ستون احراز در app.Users نیست", no_pwd)
isjson_n = len(L1(r"ISJSON"))
ctrl("C-14", "راهبرد JSON + CHECK ISJSON", isjson_n >= 6, f"{isjson_n} سایت ISJSON")
sv = L1(r"SchemaVersion")
ctrl("C-15", "دفتر نسخه SchemaVersion موجود", bool(sv), f"{len(sv)} ارجاع")

# ---------- کنترل‌های اختصاصی Stage2 ----------
s2 = "\n".join(codes["Stage2"])
L2 = lambda pat: [i + 1 for i, ln in enumerate(codes["Stage2"]) if re.search(pat, ln, re.I)]
tables_s2 = re.findall(r"CREATE TABLE\s+(?:app\.)?(\w+)", s2)
ctrl("C-16", "Stage2 = ۷ جدول دقیق", len(tables_s2) == 7, f"{len(tables_s2)}: {sorted(tables_s2)}")
roles = re.findall(r"N'(admin|applicant|committer|senior|ceo|budget|budget_cur)'", s2)
ctrl("C-17", "۷ نقش seed = نقش‌های کد مرجع؛ بدون «مسئول تأمین اعتبار»", len(set(roles)) == 7, f"{sorted(set(roles))}")
hold = L2(r"HOLDLOCK|SERIALIZABLE")
ctrl("C-18", "یافته P-07: MERGE بدون HOLDLOCK", bool(L2(r'\bMERGE\b')) and not hold, f"HOLDLOCK: {hold or 'غایب'}")
bh = L2(r"UX_BudgetHeads_SourceId")
kind = L2(r"BudgetKind\s+IN\s*\(N'capital',\s*N'current'\)|BudgetKind IS NULL OR BudgetKind IN")
ctrl("C-19", "یافته P-09: CHECK capital/current + ایندکس یکتای فیلترشده BudgetHeads", bool(bh) and len(kind) >= 1, f"UX خط {bh}؛ CHECK {len(kind)} سایت")
uq_ceil = L2(r"UNIQUE\s*\(BudgetYearId,\s*BudgetHeadId\)")
ctrl("C-20", "یافته جدید F-S2-05: BudgetCeilings بدون UNIQUE(Year,Head) برخلاف v6-F2", not uq_ceil, f"UNIQUE: {uq_ceil or 'غایب'}")
env_uq = bool(re.search(r"BudgetEnvelopes.*?UNIQUE\s*\(\s*SourceId", s2, re.S)) or L2(r"UX_BudgetEnvelopes_SourceId")
al_uq = bool(re.search(r"BudgetCeilings.*?UNIQUE\s*\(\s*SourceId", s2, re.S)) or L2(r"UX_BudgetCeilings_SourceId")
mal_uq = bool(re.search(r"ManualBudgetAllocations.*?UNIQUE\s*\(\s*SourceId", s2, re.S)) or L2(r"UX_ManualBudgetAllocations_SourceId")
ctrl("C-21", "یافته جدید F-S2-04: Envelopes/Ceilings/Allocations بدون ایندکس یکتای SourceId (خلأ مهاجرت)", not (env_uq or al_uq or mal_uq), f"Env={env_uq} Ceil={al_uq} Mal={mal_uq}")
m_env = re.search(r"CREATE TABLE app\.BudgetEnvelopes\s*\((.*?)\);", s2, re.S)
head_fk = bool(m_env and re.search(r"BudgetHeadId", m_env.group(1)))
ctrl("C-22", "یافته جدید F-S2-11: BudgetEnvelopes بدون HeadId (تفاوت ساختاری با v6-F1)", not head_fk, "بلوک CREATE TABLE اسکن شد")

# ---------- کنترل‌های اختصاصی Stage3 ----------
s3 = "\n".join(codes["Stage3"])
L3 = lambda pat: [i + 1 for i, ln in enumerate(codes["Stage3"]) if re.search(pat, ln, re.I)]
tables_s3 = re.findall(r"CREATE TABLE\s+(?:app\.)?(\w+)", s3)
ctrl("C-23", "Stage3 = ۲ جدول جدید", len(tables_s3) == 2, f"{sorted(tables_s3)}")
rt = L3(r"RouteCode\s+IN\s*\(N'purchase_request',\s*N'contractor_supply'\)")
uq_route = L3(r"UQ_MicroRequestRouting_MicroRequest\s+UNIQUE\s*\(MicroRequestId\)")
ctrl("C-24", "یافته P-12: قاعده حداکثر یک مسیر = UNIQUE(MicroRequestId) + CHECK دو مسیر", bool(rt) and bool(uq_route), f"UNIQUE {uq_route}؛ CHECK {rt}")
pre = L3(r"THROW\s+5100[123]")
ctrl("C-25", "یافته P-11: گاردهای پیش‌نیاز THROW 51001..51003 پیش از تراکنش", len(pre) == 3, f"خطوط {pre}")
et = L3(r"EntityType\s+IN\s*\(N'program',\s*N'micro_request'\)")
dedup = L3(r"UNIQUE.*CorrelationId|UX_WorkflowEvents")
ctrl("C-26", "یافته P-13: WorkflowEvents بدون قید ضدتکرار؛ EntityType پلی‌مورفیک بدون FK", bool(et) and not dedup, f"CHECK {et}؛ ضدتکرار: {dedup or 'غایب'}")
bk_p = L3(r"COL_LENGTH\(N'app\.Programs',\s*N'BudgetKind'\)")
bk_m = L3(r"COL_LENGTH\(N'app\.MicroRequests',\s*N'BudgetKind'\)")
ctrl("C-27", "افزودنی BudgetKind با گارد COL_LENGTH (افزودنی امن)", len(bk_p) == 1 and len(bk_m) == 1, f"Programs:{bk_p} Micros:{bk_m}")

# ---------- C-28: جدول‌های کل که Stage3 به آن‌ها وابسته است ----------
deps_ok = all(re.search(rf"OBJECT_ID\(N'app\.{t}',\s*N'U'\)", s3) for t in ["Programs", "MicroRequests", "Users"])
ctrl("C-28", "وابستگی‌های Stage3 هر سه با گارد OBJECT_ID", deps_ok)

# ---------- C-29: هش ورودی‌ها (پایه EVIDENCE_REGISTER) ----------
for k in FILES:
    p = os.path.join(SRC, FILES[k])
    h = hashlib.sha256(open(p, "rb").read()).hexdigest()
    n = len(open(p, encoding="utf-8-sig").read().splitlines())
    print(f"HASH {k}: {h}  lines={n}")

print("\n===== نتایج کنترل‌ها =====")
fails = 0
for cid, desc, st, ev in results:
    if st == "FAIL": fails += 1
    print(f"[{st}] {cid} — {desc}" + (f" | {ev}" if ev else ""))
print(f"\nجمع: {len(results)} کنترل | PASS={len(results)-fails} | FAIL={fails}")
print("یادآوری: FAIL اینجا یعنی «یافته ثبت‌شده در بازبینی» (مانند نبود ایندکس D-06) — نه خطای اسکریپت کنترل.")
sys.exit(0)
