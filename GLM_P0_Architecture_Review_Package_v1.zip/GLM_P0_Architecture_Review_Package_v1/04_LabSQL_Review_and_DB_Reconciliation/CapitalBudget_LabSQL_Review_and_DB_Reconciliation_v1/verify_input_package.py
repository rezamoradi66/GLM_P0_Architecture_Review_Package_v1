#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CONT-2 Phase 1 — Verify Continuation v1 package manifest against actual files."""
import hashlib, sys, io

BASE = "/home/z/my-project/continuation_workspace/CapitalBudget_Continuation_and_Next_Step_Package_v1"
MANIFEST = BASE + "/Manifest_SHA256.txt"

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

ok = fail = 0
entries = []
for line in io.open(MANIFEST, encoding="utf-8"):
    line = line.rstrip("\n")
    if not line.strip() or line.lstrip().startswith("#"):
        continue
    parts = line.split()
    if len(parts) < 3:
        continue
    digest, size, name = parts[0], int(parts[1]), parts[2]
    entries.append((digest, size, name))
    path = BASE + "/" + name
    try:
        actual = sha256(path)
        import os
        asize = os.path.getsize(path)
        if actual == digest and asize == size:
            print(f"PASS  {name}  ({asize} B)")
            ok += 1
        else:
            print(f"FAIL  {name}  expected {digest}/{size} got {actual}/{asize}")
            fail += 1
    except FileNotFoundError:
        print(f"MISSING  {name}")
        fail += 1

# reverse coverage: files on disk not in manifest
import os
on_disk = set()
for root, dirs, files in os.walk(BASE):
    for f in files:
        rel = os.path.relpath(os.path.join(root, f), BASE).replace("\\", "/")
        on_disk.add(rel)
in_manifest = {e[2] for e in entries}
extra = on_disk - in_manifest - {"Manifest_SHA256.txt"}
print(f"\nManifest entries verified: {ok} PASS / {fail} FAIL / {len(entries)} total")
print(f"Files on disk not covered by manifest: {sorted(extra) if extra else 'none (self-exclusion rule OK)'}")
sys.exit(1 if fail else 0)
