# دفتر شواهد — فایل‌های بررسی‌شده، هش‌ها و وضعیت راستی‌آزمایی

| مورد | مقدار |
|---|---|
| قاعده | «فایل واقعاً بررسی‌شده» از «فایل صرفاً معرفی‌شده» تفکیک شده؛ هش‌های SHA-256 همه در نشست جاری تازه‌محاسبه شد |
| نشانه‌ها | ✅ بررسی کامل شخصی | 🔶 بررسی بخشی (محدوده ذکر شده) | 📋 معرفی‌شده — در این نشست باز نشده |

## ۱. بسته مرجع ورودی — Continuation v1

| فایل | اندازه (B) | SHA-256 | بررسی | وضعیت راستی‌آزمایی |
|---|---:|---|---|---|
| `CapitalBudget_Continuation_and_Next_Step_Package_v1.zip` | ۵۴٬۵۳۳ | `08e61737597dbe8e7396bdb7b588d1574f4838fb212b8004b3bc089292381ea0` | ✅ CRC + استخراج + مانیفست | ۷/۷ مدخل مانیفست PASS (اسکریپت `cont2_verify_input_pkg.py`) — پوشش کامل، بدون فایل خارج از مانیفست |
| ├ 00_README.md | ۱٬۹۹۱ | `0b191708…91de5` | ✅ | خواندن کامل |
| ├ 01_Continuation_Report.docx | ۳۷٬۴۵۹ | `584fc165…05aa` | 📋 | معادل MD همان گزارش است (خود بسته چنین اعلام کرده) — MD راست‌آزمایی شد |
| ├ 02_Continuation_Report.md | ۳۱٬۸۷۵ | `9a2b26b3…773c` | ✅ | خواندن کامل — ۱۶ مشاهده P-01..P-16 استخراج و در §۴ راستی‌آزمایی شد |
| ├ 03_Status_Matrix_14Topics.csv | ۴٬۰۵۸ | `3166cc89…00f03` | ✅ | خواندن کامل |
| ├ 04_Previous_Deliverables_Inventory.csv | ۲٬۳۷۹ | `a0851d2d…050ca` | ✅ | خواندن کامل — مغایرت هش ZIP خودِ بسته (رکورد `534eb07d…` در برابر فعلی `08e61737…`) ناشی از بازنویسی عمدی ZIP برای همگام‌سازی دانلود در پایان نشست قبل است (worklog CONT-1)؛ محتوای اعضا سالم و مانیفست داخلی PASS |
| ├ 05_LabSQL_Preliminary_Observations.md | ۴٬۲۷۹ | `3eef8e34…6481b` | ✅ | خواندن کامل — همه ۱۶ مورد در این نشست تأیید شد |
| └ 06_Open_Decisions_Inventory.md | ۱٬۴۹۳ | `c3994ab6…89256` | ✅ | خواندن کامل |

## ۲. سه اسکریپت SQL آزمایشگاهی (موضوع اصلی بازبینی — از بسته GitHub، استخراج‌شده در نشست قبل)

| فایل | خط | SHA-256 | بررسی | وضعیت |
|---|---:|---|---|---|
| `CapitalBudgetManagement_Lab_Stage1.sql` | ۲۵۹ | `696a1071a43f319ad5a3fbc1a508907d209a8b86c574b974daffefec1a126f83` | ✅ کامل خط‌به‌خط | ۴۳ کنترل استاتیک (C-01..C-28) + ۹ یافته SR1 — هش قبل/بعد یکسان |
| `CapitalBudgetManagement_Lab_Stage2.sql` | ۲۱۵ | `23ca6491af9130ea25b507ee1c473e1302fb4a8fe0fce54ca27e37cadfeffa3a` | ✅ کامل خط‌به‌خط | ۸ یافته SR2 — هش قبل/بعد یکسان |
| `CapitalBudgetManagement_Lab_Stage3_DRAFT_NOT_EXECUTED.sql` | ۱۵۱ | `af6f5ba6918486912f2b03226e0318a710eedd757870221b486e17c0eed3b379` | ✅ کامل خط‌به‌خط | ۶ یافته SR3 — هش قبل/بعد یکسان؛ اعلان DRAFT/NOT EXECUTED خود فایل حفظ شد |
| `README_FOR_GLM_REVIEW.txt` بسته GitHub | ۲۰ | `ed25a55bf714ef6daaad60920270c4af2846b9d34bd9668252ecc685dd29168d` | ✅ | قواعد بازبینی فقط‌خواندنی — رعایت شد |

## ۳. اسناد مرجع v6 (مسیر A — برای ماتریس تطبیق)

| فایل | SHA-256 | بررسی | وضعیت |
|---|---|---|---|
| `CapitalBudget_Stage1_Design/03-Database-Design.md` | `087a9fe2ee07c82a…` | ✅ کامل (§1..§11) | شمارش ۴۰ جدول راستی‌آزمایی شد (A:4+B:15+C:6+D:3+E:4+F:4+G:4)؛ D-04/D-06/D-14/D-19/§11 استخراج شد |
| `CapitalBudget_Stage1_Design/06-Database-Build-Plan.md` | `c58b07b5d44e638e…` | ✅ کامل | DB-01..DB-13 + نام Lab پیشنهادی v6: `CapitalBudgetDB_Lab` + آزمون DB-A |
| `CapitalBudget_Stage1_Design/12-Remaining-Decisions-For-Employer.md` | `5f4871f2457c3a80…` | ✅ کامل | فرضیه ۱ (CapitalBudgetDB — باز) + D-21/D-22/D-05 + ۵ فرضیه |

## ۴. اسناد احراز (مسیر بحرانی OID)

| فایل | SHA-256 | بررسی | وضعیت |
|---|---|---|---|
| `Corrected_Documents/04_DATABASE_DESIGN_FA_v2.2.md` | `649faccde6985f1c…` | 🔶 بخش‌های §4.7/§4.9/§4.10 | DBA-8 (سیاست FK) + رویدادهای v2.2 |
| `Updated_Stage1_Documents/04_DATABASE_DESIGN_FA.md` (v2.1) | `b6efbaf48367d79b…` | 🔶 §4.3/§4.4/§4.6 | مدل احراز v2: Users/UserRoles/AuthSessions/LoginLockouts/SecurityEvents + SystemAuthSettings/UserExternalIdentities + TP-13 |
| `03_DECISIONS_STABILIZED_AND_OPEN_FA.md` (Corrected) | `d32689c2ed787980…` | 🔶 §3 | متن دقیق OID-A/B/C/D — عیناً به P0-3 منتقل شد، بازتعریف نشد |

## ۵. اسناد لاگ v5.3

| فایل | SHA-256 | بررسی | وضعیت |
|---|---|---|---|
| `06_LOG_DATA_MODEL_PROPOSAL.sql` (v5.2→v5.3 بسته) | `fcadcb49eb3ca199…` | 🔶 سربرگ + بخش ۰..۲ (تعریف AuditEvent/PurgeRun) | ۲۰ ستون AuditEvent + CIX/UX ضدتکرار + PROPOSAL ONLY — NOT EXECUTED؛ دوره‌های ۲/۶/۶/۳ |
| `10_IT_DBA_DEPENDENCIES_FA.md` | `4e9cb1e285ccc0ef…` | 🔶 §4 | متن دقیق LOG-DBA-1..6 — عیناً به P0-4 منتقل شد |
| `09_DECISIONS_STATUS_FA.md` | `ba6d30c2c3c3b678…` | 🔶 جدول LOG-OID | متن دقیق LOG-OID-03 (Schema) — به P0-2/P0-6 گره خورد |

## ۶. مسیر C — خط پیاده‌شده پیوست (تنها باند با شاهد اجرا)

| فایل | SHA-256 | بررسی | وضعیت |
|---|---|---|---|
| `AttachmentsModule/src/Attachments.Core/Domain/Entities.cs` | `d1889b2989bd3d1f…` | ✅ کامل (۱۳۰ خط) | ۸ جدول dbo با int/long — جمله «no EnsureCreated/Migrate» (خط ۸-۹) یعنی DDL با اسکریپت‌های دستی است |
| `02-Database/sql/02-Create-Attachment-Structure.sql` | `60a1f3e2ed0b460a…` | 🔶 سربرگ + گاردها + FKها | هدف: `CapitalBudgetManagement_Lab`؛ SQLCMD؛ Idempotent؛ امتناع از DB سیستمی |
| `02-Database/sql/05-Seed-Lab-Minimal.sql` | `b4ce03eb9361745e…` | 🔶 بخش Users + گارد | dbo.Users با PasswordHash PBKDF2 (قالب ۸۳ نویسه) + MustChangePassword=1 + گارد امتناع از اجرا روی `CapitalBudgetDB` |

## ۷. HTML مرجع (طبق قاعده مأموریت — بازبینی نشد)

| فایل | SHA-256 | بررسی | وضعیت |
|---|---|---|---|
| `Capital_Budget_Management_Stabilized_v3_1_1(1).html` | `b1d562f8a090f88bb961f7db101608ec47b17d9e2dc95bbc342a6cb66fd48e64` | 📋 فقط هش | **بایت‌به‌بایت برابر نسخه ممیزی‌شده** (هش = هش ممیزی قبلی) → تکرار ممیزی HTML ممنوع و انجام نشد؛ نتایج ممیزی معتبر ماند |

## ۸. راستی‌آزمایی یافته‌های گزارش قبلی (P-01..P-16 Continuation)

هر ۱۶ مشاهده با کنترل‌های قابل تکرار این نشست تأیید شد — از «گزارش‌شده» به «تأییدشده شخصی» ارتقا یافت:

| گروه | موارد | شاهد |
|---|---|---|
| تأییدشده با کنترل خودکار | P-01(C-13)، P-02(C-10)، P-03(C-11)، P-04(C-12)، P-05(C-14)، P-06(C-05)، P-07(C-18)، P-08(C-17)، P-09(C-19)، P-11(C-25)، P-12(C-24)، P-13(C-26)، P-14(C-01)، P-16(C-15) | ۱۴ مورد |
| تأییدشده با مطالعه مستقیم | P-10 (الگوی CATCH — ارزیابی درس LOG-FIX-15 در SR2-08)، P-15 (نام DB — غنی‌شده به FX-01 با کشف نام چهارم `CapitalBudgetDB_Lab` و برخورد دو خانواده اسکریپت) | ۲ مورد |

## ۹. موارد «صرفاً معرفی‌شده» و قابل راستی‌آزمایی نبوده

| موضوع | دلیل | پیامد |
|---|---|---|
| اجرای Stage1/2 در Lab کارفرما | هیچ شاهدی از این محیط در دسترس نیست | وضعیت: نامشخص — فرض اجراشدگی ممنوع |
| ادعای آزمون اتصال دیتابیس در آزمایشگاه کارفرما | تأییدناپذیر از این محیط (Linux بدون SQL Server/IIS) | نامشخص — ثبت در Continuation حفظ شد |
| ۱۰۸/۱۰۸ آزمون پیوست | فقط شاهد TRX درون بسته v2 — بازاجرا نشد (dotnet پس از ریست حذف شده) | «تأییدشده با شواهد بسته» — نه بازاجراشده |
| کامپایل سه اسکریپت SQL | بدون SQL Server | همه نتایج این بسته: STATIC — NOT EXECUTED |

## ۱۰. اثبات تخریب‌ناپذیری فرایند

- هش سه اسکریپت در شروع (`cont2_static_review.py` → HASH Stage1/2/3) و پس از پایان بازبینی: **یکسان** — صفر تغییر فایل ورودی.
- هیچ دستور SQL در هیچ محیطی اجرا نشد؛ هیچ اتصال دیتابیسی برقرار نشد؛ بسته ورودی و همه اسناد مرجع دست‌نخورده ماندند (هش‌های بالا تازه‌محاسبه و با رکوردهای قبلی منطبق‌اند به‌جز مورد توضیح‌داده‌شده §1).
