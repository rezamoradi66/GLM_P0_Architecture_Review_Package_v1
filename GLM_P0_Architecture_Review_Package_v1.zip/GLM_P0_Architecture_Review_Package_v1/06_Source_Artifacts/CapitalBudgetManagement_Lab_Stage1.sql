/*
  Capital Budget Management — Lab database foundation
  Target: SQL Server 2022
  Database: CapitalBudgetManagement_Lab

  IMPORTANT:
  - This is Stage 1: schema foundation for controlled migration from browser localStorage.
  - It does NOT connect the HTML application to SQL Server.
  - Do not store plaintext passwords or browser session tokens here.
  - JSON payloads preserve the current application's evolving object structure while
    a verified field-by-field migration and backend API are implemented.
*/

USE [CapitalBudgetManagement_Lab];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

IF SCHEMA_ID(N'app') IS NULL
    EXEC(N'CREATE SCHEMA [app] AUTHORIZATION [dbo];');
GO

/* Application/schema version ledger */
IF OBJECT_ID(N'app.SchemaVersion', N'U') IS NULL
BEGIN
    CREATE TABLE app.SchemaVersion
    (
        SchemaVersionId  int IDENTITY(1,1) NOT NULL CONSTRAINT PK_SchemaVersion PRIMARY KEY,
        VersionCode      varchar(30) NOT NULL,
        Description      nvarchar(400) NOT NULL,
        AppliedAtUtc     datetime2(0) NOT NULL CONSTRAINT DF_SchemaVersion_AppliedAtUtc DEFAULT SYSUTCDATETIME(),
        AppliedBy        sysname NOT NULL CONSTRAINT DF_SchemaVersion_AppliedBy DEFAULT SUSER_SNAME(),
        CONSTRAINT UQ_SchemaVersion_VersionCode UNIQUE (VersionCode)
    );
END;
GO

/* Users: no password or password-hash column is intentionally included yet.
   Authentication design belongs in the backend, using a suitable password-hashing
   library/identity provider—not the old browser-side hash. */
IF OBJECT_ID(N'app.Users', N'U') IS NULL
BEGIN
    CREATE TABLE app.Users
    (
        UserId            bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Users PRIMARY KEY,
        SourceAppUserId   nvarchar(100) NULL,
        Username          nvarchar(100) NOT NULL,
        FirstName         nvarchar(100) NULL,
        LastName          nvarchar(100) NULL,
        PersonnelNo       nvarchar(50) NULL,
        PositionTitle     nvarchar(200) NULL,
        RoleCode          nvarchar(50) NOT NULL,
        ManagementId      bigint NULL,
        UnitId            bigint NULL,
        IsActive          bit NOT NULL CONSTRAINT DF_Users_IsActive DEFAULT (1),
        AvatarUrl         nvarchar(1000) NULL,
        ExtraJson         nvarchar(max) NULL,
        CreatedAtUtc      datetime2(0) NOT NULL CONSTRAINT DF_Users_CreatedAtUtc DEFAULT SYSUTCDATETIME(),
        UpdatedAtUtc      datetime2(0) NOT NULL CONSTRAINT DF_Users_UpdatedAtUtc DEFAULT SYSUTCDATETIME(),
        RowVer            rowversion,
        CONSTRAINT UQ_Users_Username UNIQUE (Username),
        CONSTRAINT CK_Users_ExtraJson CHECK (ExtraJson IS NULL OR ISJSON(ExtraJson) = 1)
    );
END;
GO

/* Organizational hierarchy */
IF OBJECT_ID(N'app.Managements', N'U') IS NULL
BEGIN
    CREATE TABLE app.Managements
    (
        ManagementId      bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Managements PRIMARY KEY,
        SourceId          nvarchar(100) NULL,
        Name              nvarchar(250) NOT NULL,
        IsActive          bit NOT NULL CONSTRAINT DF_Managements_IsActive DEFAULT (1),
        SortOrder         int NOT NULL CONSTRAINT DF_Managements_SortOrder DEFAULT (0),
        ExtraJson         nvarchar(max) NULL,
        CreatedAtUtc      datetime2(0) NOT NULL CONSTRAINT DF_Managements_CreatedAtUtc DEFAULT SYSUTCDATETIME(),
        CONSTRAINT CK_Managements_ExtraJson CHECK (ExtraJson IS NULL OR ISJSON(ExtraJson) = 1)
    );
END;
GO

IF OBJECT_ID(N'app.Units', N'U') IS NULL
BEGIN
    CREATE TABLE app.Units
    (
        UnitId            bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Units PRIMARY KEY,
        SourceId          nvarchar(100) NULL,
        ManagementId      bigint NULL,
        Name              nvarchar(250) NOT NULL,
        IsActive          bit NOT NULL CONSTRAINT DF_Units_IsActive DEFAULT (1),
        SortOrder         int NOT NULL CONSTRAINT DF_Units_SortOrder DEFAULT (0),
        ExtraJson         nvarchar(max) NULL,
        CreatedAtUtc      datetime2(0) NOT NULL CONSTRAINT DF_Units_CreatedAtUtc DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_Units_Managements FOREIGN KEY (ManagementId) REFERENCES app.Managements(ManagementId),
        CONSTRAINT CK_Units_ExtraJson CHECK (ExtraJson IS NULL OR ISJSON(ExtraJson) = 1)
    );
END;
GO

/* Add organizational foreign keys to Users only after the referenced tables exist. */
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Users_Managements')
    ALTER TABLE app.Users ADD CONSTRAINT FK_Users_Managements
        FOREIGN KEY (ManagementId) REFERENCES app.Managements(ManagementId);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Users_Units')
    ALTER TABLE app.Users ADD CONSTRAINT FK_Users_Units
        FOREIGN KEY (UnitId) REFERENCES app.Units(UnitId);
GO

/* Budget programs / main requests */
IF OBJECT_ID(N'app.Programs', N'U') IS NULL
BEGIN
    CREATE TABLE app.Programs
    (
        ProgramId          bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Programs PRIMARY KEY,
        SourceProgramId    nvarchar(100) NOT NULL,
        ProgramCode        nvarchar(100) NULL,
        Title              nvarchar(500) NOT NULL,
        BudgetYear         int NULL,
        ManagementId       bigint NULL,
        UnitId             bigint NULL,
        ApplicantUserId    bigint NULL,
        CommitterUserId    bigint NULL,
        SeniorManagerId    bigint NULL,
        StatusCode         nvarchar(50) NULL,
        EstimatedAmount    decimal(19,4) NULL,
        SuggestedAmount    decimal(19,4) NULL,
        ApprovedAmount     decimal(19,4) NULL,
        CreatedByUserId    bigint NULL,
        CreatedAtUtc       datetime2(0) NOT NULL CONSTRAINT DF_Programs_CreatedAtUtc DEFAULT SYSUTCDATETIME(),
        UpdatedAtUtc       datetime2(0) NOT NULL CONSTRAINT DF_Programs_UpdatedAtUtc DEFAULT SYSUTCDATETIME(),
        PayloadJson        nvarchar(max) NOT NULL,
        RowVer             rowversion,
        CONSTRAINT UQ_Programs_SourceProgramId UNIQUE (SourceProgramId),
        CONSTRAINT FK_Programs_Managements FOREIGN KEY (ManagementId) REFERENCES app.Managements(ManagementId),
        CONSTRAINT FK_Programs_Units FOREIGN KEY (UnitId) REFERENCES app.Units(UnitId),
        CONSTRAINT FK_Programs_Applicant FOREIGN KEY (ApplicantUserId) REFERENCES app.Users(UserId),
        CONSTRAINT FK_Programs_Committer FOREIGN KEY (CommitterUserId) REFERENCES app.Users(UserId),
        CONSTRAINT FK_Programs_SeniorManager FOREIGN KEY (SeniorManagerId) REFERENCES app.Users(UserId),
        CONSTRAINT FK_Programs_CreatedBy FOREIGN KEY (CreatedByUserId) REFERENCES app.Users(UserId),
        CONSTRAINT CK_Programs_PayloadJson CHECK (ISJSON(PayloadJson) = 1)
    );
END;
GO

/* Micro-requests / line items belonging to a program */
IF OBJECT_ID(N'app.MicroRequests', N'U') IS NULL
BEGIN
    CREATE TABLE app.MicroRequests
    (
        MicroRequestId     bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_MicroRequests PRIMARY KEY,
        ProgramId          bigint NOT NULL,
        SourceMicroId      nvarchar(100) NOT NULL,
        Title              nvarchar(500) NULL,
        BudgetYear         int NULL,
        Amount             decimal(19,4) NULL,
        StatusCode         nvarchar(50) NULL,
        SortOrder          int NOT NULL CONSTRAINT DF_MicroRequests_SortOrder DEFAULT (0),
        PayloadJson        nvarchar(max) NOT NULL,
        CreatedAtUtc       datetime2(0) NOT NULL CONSTRAINT DF_MicroRequests_CreatedAtUtc DEFAULT SYSUTCDATETIME(),
        UpdatedAtUtc       datetime2(0) NOT NULL CONSTRAINT DF_MicroRequests_UpdatedAtUtc DEFAULT SYSUTCDATETIME(),
        RowVer             rowversion,
        CONSTRAINT UQ_MicroRequests_SourceMicroId UNIQUE (ProgramId, SourceMicroId),
        CONSTRAINT FK_MicroRequests_Programs FOREIGN KEY (ProgramId) REFERENCES app.Programs(ProgramId),
        CONSTRAINT CK_MicroRequests_PayloadJson CHECK (ISJSON(PayloadJson) = 1)
    );
END;
GO

/* Flexible catalog storage for the app's configurable base lists:
   priorities, request types, domains, units of measure, periods, benefits,
   goals, requirements, budget heads, program types, and similar catalogs. */
IF OBJECT_ID(N'app.CatalogItems', N'U') IS NULL
BEGIN
    CREATE TABLE app.CatalogItems
    (
        CatalogItemId      bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_CatalogItems PRIMARY KEY,
        CatalogType        nvarchar(80) NOT NULL,
        SourceId           nvarchar(100) NOT NULL,
        Name               nvarchar(300) NOT NULL,
        ParentSourceId     nvarchar(100) NULL,
        IsActive           bit NOT NULL CONSTRAINT DF_CatalogItems_IsActive DEFAULT (1),
        SortOrder          int NOT NULL CONSTRAINT DF_CatalogItems_SortOrder DEFAULT (0),
        PayloadJson        nvarchar(max) NULL,
        CreatedAtUtc       datetime2(0) NOT NULL CONSTRAINT DF_CatalogItems_CreatedAtUtc DEFAULT SYSUTCDATETIME(),
        CONSTRAINT UQ_CatalogItems_Type_Source UNIQUE (CatalogType, SourceId),
        CONSTRAINT CK_CatalogItems_PayloadJson CHECK (PayloadJson IS NULL OR ISJSON(PayloadJson) = 1)
    );
END;
GO

/* Singleton-style settings row(s), keyed by a stable source key */
IF OBJECT_ID(N'app.AppSettings', N'U') IS NULL
BEGIN
    CREATE TABLE app.AppSettings
    (
        SettingKey         nvarchar(100) NOT NULL CONSTRAINT PK_AppSettings PRIMARY KEY,
        SettingJson        nvarchar(max) NOT NULL,
        UpdatedAtUtc       datetime2(0) NOT NULL CONSTRAINT DF_AppSettings_UpdatedAtUtc DEFAULT SYSUTCDATETIME(),
        UpdatedBy          nvarchar(100) NULL,
        CONSTRAINT CK_AppSettings_SettingJson CHECK (ISJSON(SettingJson) = 1)
    );
END;
GO

/* Audit trail for future backend operations. Write to this table from the backend,
   not directly from an untrusted browser client. */
IF OBJECT_ID(N'app.AuditLog', N'U') IS NULL
BEGIN
    CREATE TABLE app.AuditLog
    (
        AuditLogId         bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuditLog PRIMARY KEY,
        OccurredAtUtc      datetime2(0) NOT NULL CONSTRAINT DF_AuditLog_OccurredAtUtc DEFAULT SYSUTCDATETIME(),
        ActorUserId        bigint NULL,
        ActionCode         nvarchar(100) NOT NULL,
        EntityType         nvarchar(100) NULL,
        EntitySourceId     nvarchar(100) NULL,
        CorrelationId      uniqueidentifier NULL,
        DetailsJson        nvarchar(max) NULL,
        CONSTRAINT FK_AuditLog_Users FOREIGN KEY (ActorUserId) REFERENCES app.Users(UserId),
        CONSTRAINT CK_AuditLog_DetailsJson CHECK (DetailsJson IS NULL OR ISJSON(DetailsJson) = 1)
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Programs_Year_Status' AND object_id = OBJECT_ID(N'app.Programs'))
    CREATE INDEX IX_Programs_Year_Status ON app.Programs(BudgetYear, StatusCode);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Programs_Management_Unit' AND object_id = OBJECT_ID(N'app.Programs'))
    CREATE INDEX IX_Programs_Management_Unit ON app.Programs(ManagementId, UnitId);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_MicroRequests_Program_Year' AND object_id = OBJECT_ID(N'app.MicroRequests'))
    CREATE INDEX IX_MicroRequests_Program_Year ON app.MicroRequests(ProgramId, BudgetYear);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_CatalogItems_Type_Active' AND object_id = OBJECT_ID(N'app.CatalogItems'))
    CREATE INDEX IX_CatalogItems_Type_Active ON app.CatalogItems(CatalogType, IsActive, SortOrder);
GO

IF NOT EXISTS (SELECT 1 FROM app.SchemaVersion WHERE VersionCode = 'LAB-FOUNDATION-1')
BEGIN
    INSERT INTO app.SchemaVersion(VersionCode, Description)
    VALUES ('LAB-FOUNDATION-1',
            N'Initial lab schema foundation; not yet wired to the browser application.');
END;
GO

/* Verification output */
SELECT N'CapitalBudgetManagement_Lab' AS DatabaseName,
       s.name AS SchemaName,
       t.name AS TableName
FROM sys.tables AS t
JOIN sys.schemas AS s ON s.schema_id = t.schema_id
WHERE s.name = N'app'
ORDER BY t.name;
GO
