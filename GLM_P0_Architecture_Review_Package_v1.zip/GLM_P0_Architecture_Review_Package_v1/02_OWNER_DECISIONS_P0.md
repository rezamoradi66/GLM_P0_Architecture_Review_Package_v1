# Owner P0 Decisions — Quick Reference

1. **P0-1 / D-06 — PersonnelNo**
   - Enforce uniqueness before operational data entry begins.
   - Never reassign a personnel number to another person after exit.
   - Determine field length from actual personnel-number format; no final length selected yet.

2. **P0-2 — Audit**
   - `AuditEvent` is the target logical source for business/security audit events.
   - Final schema and treatment of existing `app.AuditLog` require review of current data and dependencies.
   - No table drop/change authorized.

3. **P0-3 — Authentication**
   - Support Local and Active Directory.
   - Authorized site/organization administrator selects the active method according to organization policy.
   - Server-side authentication and authorization required.

4. **P0-4 — Log purge**
   - Controlled, batched, observable, safely stoppable/resumable process.
   - Batch size 5,000 is provisional only.
   - No purge or deletion authorized.

5. **P0-5 — Architecture convergence**
   - v6 is the reference baseline.
   - Reuse Lab and Appendix v2 assets only after compatibility review.
   - One coherent target architecture; no blind merge.

6. **P0-6 — Naming**
   - Target DB: `CapitalBudgetDB`.
   - Target lab DB: `CapitalBudgetDB_Lab`.
   - Existing `CapitalBudgetManagement_Lab` must remain unchanged.
   - Schemas: `dbo`, `rep`, `audit`.
   - Validate against the actual environment before execution.
